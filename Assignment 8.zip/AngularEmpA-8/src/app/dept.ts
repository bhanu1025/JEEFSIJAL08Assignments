export class Dept {
    deptId:number;
    deptName:string;
}
