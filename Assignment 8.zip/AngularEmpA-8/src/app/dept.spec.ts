import { Dept } from './dept';

describe('Dept', () => {
  it('should create an instance', () => {
    expect(new Dept()).toBeTruthy();
  });
});
